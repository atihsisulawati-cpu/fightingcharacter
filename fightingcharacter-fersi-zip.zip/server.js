// Fighting Character: server API laporan + static assets, tanpa package tambahan.
// Jalankan: node server.js
const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '6767';
const ROOT = __dirname;
const DATA = path.join(ROOT, 'data');
const DB = path.join(DATA, 'issues.json');
fs.mkdirSync(DATA, { recursive: true });
if (!fs.existsSync(DB)) fs.writeFileSync(DB, '[]', 'utf8');

function sendJson(res, status, value) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(JSON.stringify(value));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (raw.length > 20000) { reject(new Error('Permintaan terlalu besar.')); req.destroy(); }
    });
    req.on('end', () => { try { resolve(JSON.parse(raw || '{}')); } catch { reject(new Error('JSON tidak valid.')); } });
    req.on('error', reject);
  });
}
function readIssues() {
  try { const value = JSON.parse(fs.readFileSync(DB, 'utf8')); return Array.isArray(value) ? value : []; }
  catch { return []; }
}
const mime = {
  '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8',
  '.json':'application/json; charset=utf-8', '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg',
  '.gif':'image/gif', '.webp':'image/webp', '.svg':'image/svg+xml', '.ico':'image/x-icon',
  '.mp4':'video/mp4', '.webm':'video/webm', '.mp3':'audio/mpeg', '.ogg':'audio/ogg', '.wav':'audio/wav', '.woff':'font/woff', '.woff2':'font/woff2'
};

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (req.method === 'POST' && url.pathname === '/api/issues') {
    try {
      const body = await readBody(req);
      const username = String(body.username || '').trim().slice(0, 30);
      const problem = String(body.problem || '').trim();
      if (!username) return sendJson(res, 400, { error: 'Username tidak ditemukan.' });
      if (username.toLowerCase() === 'gojodanprototype') return sendJson(res, 403, { error: 'Akun admin tidak dapat mengirim laporan pemain.' });
      if (!problem) return sendJson(res, 400, { error: 'Isi laporan masih kosong.' });
      if (problem.length > 2000) return sendJson(res, 413, { error: 'Laporan maksimal 2000 karakter.' });
      const all = readIssues();
      all.push({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7), username, problem, date: new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) });
      fs.writeFileSync(DB, JSON.stringify(all, null, 2), 'utf8');
      return sendJson(res, 201, { ok: true });
    } catch (error) { return sendJson(res, 400, { error: error.message || 'Permintaan tidak valid.' }); }
  }
  if (req.method === 'GET' && url.pathname === '/api/issues') {
    if (req.headers['x-admin-password'] !== ADMIN_PASSWORD) return sendJson(res, 401, { error: 'Akses admin ditolak.' });
    return sendJson(res, 200, { issues: readIssues() });
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end('Method not allowed'); }

  let pathname;
  try { pathname = decodeURIComponent(url.pathname); } catch { return sendJson(res, 400, { error: 'Path tidak valid.' }); }
  if (pathname === '/') pathname = '/index.html';
  const file = path.resolve(ROOT, '.' + pathname);
  // Hanya izinkan file di folder proyek. Lindungi data laporan dan file server dari akses publik.
  if (!file.startsWith(ROOT + path.sep) || file === DB || file.startsWith(DATA + path.sep) || path.basename(file) === 'server.js' || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('File tidak ditemukan. Pastikan folder aset game ikut diunggah.');
  }
  res.writeHead(200, { 'Content-Type': mime[path.extname(file).toLowerCase()] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff' });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
});
server.listen(PORT, '0.0.0.0', () => console.log(`Fighting Character berjalan pada port ${PORT}`));
